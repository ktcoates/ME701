#!bin/bash

givenfile=$1

if test -e $givenfile; then
a=$(pwd)
	if test -e /home/kyle/trash; then
		echo "The path exists!"
		mv $givenfile /home/kyle/trash
	else
		echo "The path does not exist!"
		cd /home/kyle
		mkdir trash
		cd $a
		mv $givenfile /home/kyle/trash
	fi
else
	echo "The file that you want to move does not exist."
fi
